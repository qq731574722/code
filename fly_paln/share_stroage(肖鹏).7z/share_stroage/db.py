# -*- coding: utf-8 -*-

class DBDriver(object):
    def __init__(self):
        pass

    def query(self, table_name, filter):
        pass

